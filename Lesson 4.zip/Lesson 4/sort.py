# Sorted
hello = 'Hello'

list_num = [3, 1, 10, 0]

list_tuples = [(0, 1),(0, 2, 3),(0, 2), (100, 3),(100, 2), (10, 0), (1, 0)]

list_words = ['HEllo','hello']

# print(hello)
# print(sorted(hello))

# print(list_num)
# print(sorted(list_num))
# print(sorted(list_num, reverse= True))

# print(list_tuples)
# print(sorted(list_tuples, key = len))

# print(list_words)
# print(sorted(list_words, reverse= True))

# .sort()
# print(list_num)
# print(sorted(list_num))
# print(list_num)

print(list_num)
print(list_num.sort())
print(list_num)



